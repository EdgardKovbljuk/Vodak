const express = require('express');
const ejs = require('ejs');
const path = require('path');
const app = express();
const port = 80;
const fs = require('fs');



// Nastaven� view engine pro EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

// Seznam existuj�c�ch jmen
const existingNicknames = ['adam', 'eva', 'john']; // M��ete sem vlo�it existuj�c� jm�na nebo na��st z extern�ho zdroje

// Importov�n� knihovny pro middleware
const bodyParser = require('body-parser');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());


app.get('/', (req, res) => {
    res.render('index', { registry: registry }); // Poslat prom�nnou `registry` do �ablony `index`
});

app.get('/login', (req, res) => {
    res.render('login'); // Upravte na spr�vnou cestu k va�emu souboru pro p�ihl�en�
});

app.get('/registrace', (req, res) => {
    try {
        const data = fs.readFileSync('registrations.json', 'utf8');
        const registeredUsers = JSON.parse(data);
        res.render('registrace', { registeredUsers: registeredUsers });
    } catch (err) {
        console.error('Chyba pri cteni souboru:', err);
        res.status(500).send('Chyba pri cteni souboru.');
    }
});

app.get('/contact', (req, res) => {
    res.render('contact'); // p�izp�sobte podle va�� struktury a n�zvu souboru
});


function writeToJSONFile(data) {
    const jsonData = JSON.stringify(data, null, 2); // Konvertov�n� dat na JSON
    fs.writeFile('registrations.json', jsonData, 'utf8', (err) => {
        if (err) {
            console.error('Chyba pri z�pisu do souboru:', err);
            return;
        }
        console.log('Data zapsana do souboru "registrations.json"');
    });
}

let registry = [];



function validateNickname(nickname) {
    const nicknameRegex = /^[A-Za-z0-9]{2,20}$/;
    return nicknameRegex.test(nickname);
}

app.post('/submitRegistration', (req, res) => {
    const { name, nick, is_swimmer, canoe_companion, email } = req.body;

    if (!nick || !is_swimmer || !email) {
        return res.status(400).send('Chybejici informace ve formulari.');
    }

    if (is_swimmer !== '1') {
        return res.status(400).send('Osoba musi umet plavat.');
    }

    const isNickValid = validateNickname(nick);
    if (!isNickValid) {
        return res.status(400).send('Neplatna prezdivka (nick).');
    }

    if (canoe_companion) {
        const isCompanionValid = validateNickname(canoe_companion);
        if (!isCompanionValid) {
            return res.status(400).send('Neplatny spolecnik na lodi (kanoe_kamarad).');
        }
    }

    const isEmailDuplicate = isDuplicateValue(email, 'email');
    if (isEmailDuplicate) {
        return res.status(400).send('E-mailova adresa jiz existuje.');
    }

    const registration = {
        name: name,
        nick: nick,
        is_swimmer: is_swimmer,
        canoe_companion: canoe_companion || "",
        email: email
    };

appendToJSONFile(registration); // P�id�n� nov� registrace do JSON souboru

    registry.push(registration);
	
	// Z�pis registrac� do JSON souboru
    writeToJSONFile(registry);

	 res.render('index');
});


// Funkce pro kontrolu duplicit v registra�n�ch datech
function isDuplicateValue(value, property) {
    const duplicate = registry.some(entry => entry[property] === value);
    return duplicate;
}
// Upravte app.js - P�id�n� nov�ho endpointu pro kontrolu nickname

// Nov� endpoint pro kontrolu nickname
app.get('/api/check-nickname', (req, res) => {
    const { nick } = req.query;
    const lowercaseNick = nick.toLowerCase(); // P�evede zadan� jm�no na mal� p�smena

    fs.readFile('registrations.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Chyba pri cteni souboru:', err);
            return res.status(500).send('Chyba pri cteni souboru.');
        }

        const registrations = JSON.parse(data);
        const existingNicknames = registrations.map(entry => entry.nick.toLowerCase());

        if (existingNicknames.includes(lowercaseNick)) {
            res.json({ exists: true });
        } else {
            res.json({ exists: false });
        }
    });
});

// Zde by m�lo b�t m�sto, kde inicializujete sv�j server a nastavujete routov�n�

app.get('/api/check-email', (req, res) => {
    const { email } = req.query;
    const lowercaseEmail = email .toLowerCase(); // P�evede zadany email na mal� p�smena

    // Prove�te ov��en� existence e-mailu v datab�zi zde
    // Nap��klad kontrola v JSON souboru nebo p��stup k datab�zi

    // Upravte tuto logiku podle va�ich skute�n�ch dat
   fs.readFile('registrations.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Chyba pri cteni souboru:', err);
            return res.status(500).send('Chyba při cteni souboru.');
        }

        const registrations = JSON.parse(data);
        const existingEmails= registrations.map(entry => entry.email.toLowerCase());

    if (existingEmails.includes(email)) {
        res.json({ exists: true });
    } else {
        res.json({ exists: false });
    }
});
});







// Zm�na zp�sobu ukl�d�n� registrac� do JSON souboru
function appendToJSONFile(data) {
    fs.readFile('registrations.json', 'utf8', (err, fileData) => {
        if (err) {
            console.error('Chyba při čtení souboru:', err);
            return;
        }

        let registrations = JSON.parse(fileData);

        // Kontrola, zda nová registrace již existuje v souboru
        const isDuplicate = registrations.some(entry => entry.nick === data.nick && entry.email === data.email);
        if (isDuplicate) {
            console.log('Duplicitní zaznam, neni potřeba pridavat.');
            return;
        }

        registrations.push(data);

        const jsonData = JSON.stringify(registrations, null, 2);

        fs.writeFile('registrations.json', jsonData, 'utf8', (err) => {
            if (err) {
                console.error('Chyba pri zapisu do souboru:', err);
                return;
            }
            console.log('Data uspesne zapsana do souboru "registrations.json"');
        });
    });
}


// Spu�t�n� serveru
app.listen(port, () => {
    console.log(`Server b�� na adrese http://localhost:${port}`);
});