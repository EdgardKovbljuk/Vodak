document.addEventListener('DOMContentLoaded', function() {
    const nicknameInput = document.getElementById('nick');
    const registrationForm = document.getElementById('registrationForm');

    nicknameInput.addEventListener('change', function() {
        const nick = nicknameInput.value;
        fetch(`/api/check-nickname?nick=${nick}`)
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    alert('Nickname already exists! Please choose a different one.');
                    registrationForm.onsubmit = function(event) {
                        event.preventDefault();
                    };
                } else {
                    registrationForm.onsubmit = null;
                }
            });
    });
});
